---
name: data-extraction
description: Use this skill to extract structured data from unstructured email content and web pages. Provides patterns for identifying companies, amounts, dates, and key entities from raw text.
---

# Data Extraction

## When to Use
- Parsing email bodies to extract company names, amounts, dates
- Extracting structured information from web articles
- Identifying named entities (people, organizations, products)
- Converting unstructured competitive intelligence into structured signals

## Extraction Patterns

### Company Detection
1. Look for capitalized proper nouns followed by business indicators (Inc, SAS, Ltd, GmbH)
2. Check for known competitor names from configuration/state
3. Identify companies mentioned in context of funding, launches, partnerships
4. Cross-reference with web search to confirm company identity

### Financial Data
1. Extract monetary amounts with currency symbols ($, EUR)
2. Identify funding rounds (Seed, Series A/B/C)
3. Detect revenue/ARR mentions
4. Note valuation figures when present

### Temporal Data
1. Extract explicit dates and timestamps
2. Identify relative time references ("last week", "Q1 2026")
3. Detect deadlines and timeline mentions
4. Map events to a timeline for trend analysis

### Signal Classification
1. Map extracted data to signal types (product_launch, pricing_change, etc.)
2. Assign relevance based on:
   - Direct mention of tracked competitors → higher relevance
   - Impact on our market segment → higher relevance
   - Recency of the information → more recent = higher relevance
   - Source reliability → established sources = higher confidence

## Output Format
Always structure extracted data as:
```json
{
  "entity": "Company Name",
  "data_type": "funding|product|hiring|...",
  "value": "extracted value",
  "confidence": "high|medium|low",
  "source": "email|web|...",
  "raw_context": "original text snippet"
}
```
