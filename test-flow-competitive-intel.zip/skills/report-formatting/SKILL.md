---
name: report-formatting
description: Use this skill to format competitive intelligence reports with proper structure, executive summaries, and actionable insights. Adapts detail level based on report_depth configuration.
---

# Report Formatting

## When to Use
- Generating the final competitive intelligence report
- Structuring signals into a readable executive summary
- Adapting report depth (summary/detailed/exhaustive)
- Formatting action items with priority and deadlines

## Report Depth Guidelines

### Summary Mode
- Executive summary: 2-3 sentences
- Top 3 signals only (highest relevance)
- Actions list: title + priority only
- No source details

### Detailed Mode (Default)
- Executive summary: 3-5 sentences
- All high/critical signals with descriptions
- Medium signals listed briefly
- Actions with full context and recommendations
- Key sources cited

### Exhaustive Mode
- Full executive summary with trend analysis
- ALL signals regardless of relevance level
- Complete source attribution for each signal
- Detailed competitor profiles with changes since last run
- Sentiment analysis with supporting evidence
- Historical comparison with previous runs

## Formatting Rules
1. Start with the executive summary — decision makers read this first
2. Group signals by competitor, then by relevance
3. Actions should be SMART (Specific, Measurable, Achievable, Relevant, Time-bound)
4. Use consistent terminology throughout the report
5. Include confidence level for each signal
6. When referencing previous state, highlight what changed

## Language Adaptation
- **French (fr)**: Professional business French, avoid anglicisms except for established terms (SaaS, B2B, startup)
- **English (en)**: Clear business English, direct and concise
