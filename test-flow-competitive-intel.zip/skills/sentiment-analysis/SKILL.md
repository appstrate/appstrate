---
name: sentiment-analysis
description: Use this skill to analyze market sentiment around competitors based on email content, news articles, and web sources. Provides frameworks for sentiment classification and trend detection.
---

# Sentiment Analysis

## When to Use
- Evaluating the overall market perception of a competitor
- Detecting shifts in sentiment over time
- Identifying potential risks or opportunities from public perception
- Comparing sentiment trends across competitors

## Sentiment Categories

### Primary Sentiment
- **positive**: Growth signals, good press, customer praise, successful launches
- **negative**: Layoffs, bad press, customer complaints, product failures
- **neutral**: Factual updates without clear positive/negative connotation
- **mixed**: Contains both positive and negative signals in balance

### Trend Assessment
- **improving**: Sentiment more positive than previous assessment
- **declining**: Sentiment more negative than previous assessment
- **stable**: No significant change in sentiment
- **volatile**: Rapid changes in sentiment direction

## Analysis Framework

### Source Weighting
1. **Tier 1** (high weight): Industry analysts, major tech press (TechCrunch, Les Echos)
2. **Tier 2** (medium weight): Blog posts, newsletters, social mentions
3. **Tier 3** (low weight): Unverified sources, anonymous posts, automated alerts

### Contextual Factors
- Consider the source's historical bias
- Account for PR-driven content vs organic mentions
- Separate fact-based reporting from opinion pieces
- Weight recent signals more heavily than older ones

### SWOT Signal Mapping
Map each sentiment signal to a SWOT category:
- **Strength**: Positive internal factor (new product, strong team, funding)
- **Weakness**: Negative internal factor (turnover, technical debt, bad reviews)
- **Opportunity**: Positive external factor (market growth, regulatory change favoring them)
- **Threat**: Negative external factor (new competitor, market downturn, regulation)

## Output Structure
```json
{
  "company": "Competitor Name",
  "sentiment": {
    "current": "positive|negative|neutral|mixed",
    "previous": "positive|negative|neutral|mixed|null",
    "trend": "improving|declining|stable|volatile",
    "confidence": "high|medium|low"
  },
  "key_drivers": [
    { "factor": "Product launch well received", "impact": "positive", "weight": "high" },
    { "factor": "Key engineer departure", "impact": "negative", "weight": "medium" }
  ],
  "swot": {
    "strengths": ["..."],
    "weaknesses": ["..."],
    "opportunities": ["..."],
    "threats": ["..."]
  }
}
```
